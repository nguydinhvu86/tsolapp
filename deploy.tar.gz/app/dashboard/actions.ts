'use server';

import { prisma } from '@/lib/prisma';
import { Quote, Contract, Handover, PaymentRequest, ContractAppendix, Dispatch } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { buildViewFilter } from '@/lib/permissions';

export async function getDashboardStats(userId?: string, employeeId?: string) {
    try {
        const session = await getServerSession(authOptions);
        const perms = session?.user?.permissions || [];
        const currentUserId = session?.user?.id || userId || '';
        const isAdminOrManager = session?.user?.role === 'ADMIN' || session?.user?.role === 'MANAGER';

        const estFilter = buildViewFilter(currentUserId, perms, 'SALES_ESTIMATES', 'creatorId');
        const conFilter = buildViewFilter(currentUserId, perms, 'CONTRACTS', 'creatorId');
        const hanFilter = buildViewFilter(currentUserId, perms, 'HANDOVERS', 'creatorId');
        const payFilter = buildViewFilter(currentUserId, perms, 'PAYMENTS', 'creatorId');
        const disFilter = buildViewFilter(currentUserId, perms, 'DISPATCHES', 'creatorId');
        let cusFilter: any = buildViewFilter(currentUserId, perms, 'CUSTOMERS', 'creatorId');
        if (cusFilter.creatorId) {
            cusFilter = {
                OR: [
                    { activityLogs: { some: { userId: currentUserId } } },
                    { managers: { some: { id: currentUserId } } },
                    { quotes: { some: { creatorId: currentUserId } } },
                    { contracts: { some: { creatorId: currentUserId } } },
                    { leads: { some: { creatorId: currentUserId } } },
                    { salesInvoices: { some: { OR: [{ creatorId: currentUserId }, { salespersonId: currentUserId }, { managers: { some: { id: currentUserId } } }] } } },
                    { salesEstimates: { some: { OR: [{ creatorId: currentUserId }, { salespersonId: currentUserId }, { managers: { some: { id: currentUserId } } }] } } },
                    { salesOrders: { some: { creatorId: currentUserId } } }
                ]
            };
        }
        const poFilter = buildViewFilter(currentUserId, perms, 'PURCHASE_ORDERS', 'creatorId');
        const invFilter = buildViewFilter(currentUserId, perms, 'SALES_INVOICES', 'creatorId');

        const leadFilter = !isAdminOrManager ? { OR: [{ creatorId: currentUserId }, { assignedToId: currentUserId }, { assignees: { some: { userId: currentUserId } } }] } : {};

        const [
            estimates,
            contracts,
            handovers,
            payments,
            appendices,
            dispatches,
            customers,
            myTasks,
            purchaseOrders,
            salesInvoices,
            leads
        ] = await Promise.all([
            estFilter.id === 'UNAUTHORIZED_NO_ACCESS' ? Promise.resolve([]) : prisma.salesEstimate.findMany({
                select: { id: true, status: true, validUntil: true, date: true, createdAt: true, customer: { select: { name: true } }, code: true, totalAmount: true },
                where: { AND: [estFilter as any, employeeId ? { OR: [{ creatorId: employeeId }, { salespersonId: employeeId }, { managers: { some: { id: employeeId } } }] } : {}] },
                orderBy: { createdAt: 'desc' },
                take: 500
            }),
            conFilter.id === 'UNAUTHORIZED_NO_ACCESS' ? Promise.resolve([]) : prisma.contract.findMany({ select: { id: true, status: true, createdAt: true, customer: { select: { name: true } }, title: true }, where: conFilter as any, orderBy: { createdAt: 'desc' }, take: 200 }),
            hanFilter.id === 'UNAUTHORIZED_NO_ACCESS' ? Promise.resolve([]) : prisma.handover.findMany({ select: { id: true, status: true, createdAt: true, customer: { select: { name: true } }, title: true }, where: hanFilter as any, orderBy: { createdAt: 'desc' }, take: 100 }),
            payFilter.id === 'UNAUTHORIZED_NO_ACCESS' ? Promise.resolve([]) : prisma.paymentRequest.findMany({ select: { id: true, status: true, createdAt: true, customer: { select: { name: true } }, title: true }, where: payFilter as any, orderBy: { createdAt: 'desc' }, take: 100 }),
            conFilter.id === 'UNAUTHORIZED_NO_ACCESS' ? Promise.resolve([]) : prisma.contractAppendix.findMany({ select: { id: true, status: true, createdAt: true, contract: { select: { title: true } }, title: true }, where: { contract: conFilter as any }, orderBy: { createdAt: 'desc' }, take: 100 }),
            disFilter.id === 'UNAUTHORIZED_NO_ACCESS' ? Promise.resolve([]) : prisma.dispatch.findMany({ select: { id: true, status: true, createdAt: true, customer: { select: { name: true } }, title: true }, where: disFilter as any, orderBy: { createdAt: 'desc' }, take: 100 }),
            cusFilter.id === 'UNAUTHORIZED_NO_ACCESS' ? Promise.resolve([]) : prisma.customer.findMany({ select: { id: true, name: true, createdAt: true, taxCode: true, phone: true }, where: cusFilter as any, orderBy: { createdAt: 'desc' }, take: 10 }),
            userId ? prisma.task.findMany({ where: { OR: [{ assignees: { some: { userId: userId } } }, { creatorId: userId }, { observers: { some: { userId: userId } } }], status: { not: 'COMPLETED' } }, orderBy: { dueDate: 'asc' }, take: 10, select: { id: true, title: true, dueDate: true, priority: true } }) : Promise.resolve([]),
            poFilter.id === 'UNAUTHORIZED_NO_ACCESS' ? Promise.resolve([]) : prisma.purchaseOrder.findMany({ select: { id: true, status: true, totalAmount: true, createdAt: true, supplier: { select: { name: true } } }, where: poFilter as any, orderBy: { createdAt: 'desc' }, take: 500 }),
            invFilter.id === 'UNAUTHORIZED_NO_ACCESS' ? Promise.resolve([]) : prisma.salesInvoice.findMany({
                select: { id: true, status: true, totalAmount: true, paidAmount: true, createdAt: true, date: true, dueDate: true, code: true, customer: { select: { name: true } } },
                where: { AND: [invFilter as any, employeeId ? { OR: [{ creatorId: employeeId }, { salespersonId: employeeId }, { managers: { some: { id: employeeId } } }] } : {}] },
                orderBy: { createdAt: 'desc' },
                take: 1000
            }),
            prisma.lead.findMany({
                select: { id: true, code: true, name: true, company: true, contactName: true, status: true, estimatedValue: true, createdAt: true },
                where: employeeId ? {
                    OR: [
                        { creatorId: employeeId },
                        { assignedToId: employeeId },
                        { assignees: { some: { userId: employeeId } } }
                    ]
                } : leadFilter,
                orderBy: { createdAt: 'desc' },
                take: 1000
            })
        ]);

        // Financial Aggregations
        const currentYear = new Date().getFullYear();
        const currentMonth = new Date().getMonth();

        // Cash Flow Aggregation (Current Year)
        const startOfYear = new Date(currentYear, 0, 1);
        const endOfYear = new Date(currentYear, 11, 31, 23, 59, 59, 999);

        const [
            allSalesPayments,
            allPurchasePayments,
            allExpenses
        ] = await Promise.all([
            prisma.salesPayment.findMany({
                where: {
                    date: { gte: startOfYear, lte: endOfYear },
                    ...(employeeId ? {
                        allocations: {
                            some: {
                                invoice: {
                                    OR: [
                                        { creatorId: employeeId },
                                        { salespersonId: employeeId },
                                        { managers: { some: { id: employeeId } } }
                                    ]
                                }
                            }
                        }
                    } : {})
                },
                select: { amount: true, date: true }
            }),
            prisma.purchasePayment.findMany({
                where: { date: { gte: startOfYear, lte: endOfYear } },
                select: { amount: true, date: true }
            }),
            prisma.expense.findMany({
                where: {
                    status: { notIn: ['DRAFT', 'CANCELLED'] },
                    date: { gte: startOfYear, lte: endOfYear }
                },
                select: { amount: true, date: true }
            })
        ]);

        const cashFlow = Array.from({ length: 12 }, (_, i) => ({
            name: `T${i + 1}`,
            income: 0,
            expense: 0,
            supplierPayment: 0
        }));

        allSalesPayments.forEach(p => {
            if (p.date) {
                const month = new Date(p.date).getMonth();
                cashFlow[month].income += p.amount || 0;
            }
        });

        allPurchasePayments.forEach(p => {
            if (p.date) {
                const month = new Date(p.date).getMonth();
                cashFlow[month].supplierPayment += p.amount || 0;
            }
        });

        allExpenses.forEach(e => {
            if (e.date) {
                const month = new Date(e.date).getMonth();
                cashFlow[month].expense += e.amount || 0;
            }
        });

        // 1. Phân tích Mua Hàng (Purchase Orders)
        let totalPurchaseParams = { total: 0, thisMonth: 0, lastMonth: 0 };
        purchaseOrders.forEach(po => {
            if (po.status !== 'CANCELLED') {
                const poDate = new Date(po.createdAt);
                totalPurchaseParams.total += po.totalAmount || 0;
                if (poDate.getFullYear() === currentYear) {
                    if (poDate.getMonth() === currentMonth) totalPurchaseParams.thisMonth += po.totalAmount || 0;
                    if (poDate.getMonth() === currentMonth - 1) totalPurchaseParams.lastMonth += po.totalAmount || 0;
                }
            }
        });

        // 2. Phân tích Công Nợ / Hóa Đơn (Sales Invoices)
        let invoiceParams = {
            totalRevenue: 0,
            totalDebt: 0,
            thisMonthRevenue: 0,
            lastMonthRevenue: 0
        };
        salesInvoices.forEach(inv => {
            if (inv.status !== 'DRAFT' && inv.status !== 'CANCELLED') {
                const invDate = new Date(inv.date || inv.createdAt);

                // Revenue
                invoiceParams.totalRevenue += (inv.totalAmount || 0);
                if (invDate.getFullYear() === currentYear) {
                    if (invDate.getMonth() === currentMonth) invoiceParams.thisMonthRevenue += (inv.totalAmount || 0);
                    if (invDate.getMonth() === currentMonth - 1) invoiceParams.lastMonthRevenue += (inv.totalAmount || 0);
                }

                // Debt = Total - Paid
                const debt = (inv.totalAmount || 0) - (inv.paidAmount || 0);
                if (debt > 0) {
                    invoiceParams.totalDebt += debt;
                }
            }
        });

        return {
            totalQuotes: estimates.length,
            acceptedQuotes: estimates.filter(q => q.status === 'ACCEPTED').length,
            totalContracts: contracts.length,
            signedContracts: contracts.filter(c => c.status === 'SIGNED').length,
            financialMetrics: {
                purchase: totalPurchaseParams,
                invoices: invoiceParams,
                cashFlow: cashFlow // Pass cash flow data to client
            },
            // Pass raw arrays for client-side chart processing if needed, 
            // but usually we aggregate on server. For this scale, passing lightweight arrays is okay.
            recentActivity: {
                quotes: estimates.slice(0, 100),
                contracts: contracts.slice(0, 100),
                handovers: handovers.slice(0, 100),
                payments: payments.slice(0, 100),
                appendices: appendices.slice(0, 100),
                dispatches: dispatches.slice(0, 100)
            },
            recentCustomers: customers,
            myTasks: myTasks,
            recentPurchaseOrders: purchaseOrders,
            recentQuotes: estimates.slice(0, 10), // Specifically for the quotes list widget
            chartDataSources: {
                quotes: estimates,
                contracts: contracts,
                invoices: salesInvoices,
                leads: leads
            }
        };
    } catch (e) {
        console.error("Dashboard stats error", e);
        return null;
    }
}

export async function getDashboardConfig(userId: string) {
    try {
        const user = await prisma.user.findUnique({
            where: { id: userId },
            select: { dashboardConfig: true }
        });
        return user?.dashboardConfig || "[]";
    } catch (e) {
        console.error("Get dashboard config error", e);
        return "[]";
    }
}

export async function saveDashboardConfig(userId: string, configJson: string) {
    try {
        await prisma.user.update({
            where: { id: userId },
            data: { dashboardConfig: configJson }
        });
        return { success: true };
    } catch (e) {
        console.error("Save dashboard config error", e);
        return { success: false, error: "Failed to save configuration" };
    }
}

export async function updateDashboardTaskStatus(taskId: string, status: string) {
    try {
        const { getServerSession } = await import('next-auth');
        const { authOptions } = await import('@/lib/authOptions');
        const session = await getServerSession(authOptions);
        if (!session?.user?.id) return { success: false, error: 'Unauthorized' };

        const { updateTaskStatus } = await import('@/app/tasks/actions');
        await updateTaskStatus(taskId, status, session.user.id);

        const { revalidatePath } = await import('next/cache');
        revalidatePath('/dashboard');
        return { success: true };
    } catch (e: any) {
        console.error("Failed to update task from dashboard:", e);
        return { success: false, error: e.message };
    }
}

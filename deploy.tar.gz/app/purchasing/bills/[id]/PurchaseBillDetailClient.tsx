'use client';
import { formatDate } from '@/lib/utils/formatters';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Calendar, FileText, ShoppingCart, CheckSquare, Building, CreditCard, Clock, Plus, Trash2, FileDown, ExternalLink, Copy, XCircle, AlertTriangle } from 'lucide-react';
import { TaskPanel } from '@/app/components/tasks/TaskPanel';
import Link from 'next/link';
import { uploadPurchaseBillDocument, cancelPurchaseBill, updatePurchaseBillNotes } from '@/app/purchasing/actions';
import { Pagination, usePagination } from '@/app/components/ui/Pagination';
import { DocumentPreviewModal } from '@/app/components/ui/DocumentPreviewModal';

export function PurchaseBillDetailClient({ bill, tasks, users }: { bill: any, tasks: any[], users: any[] }) {
    const router = useRouter();
    const [activeTab, setActiveTab] = useState<'items' | 'payments' | 'tasks'>('items');

    // Document State
    const [localBill, setLocalBill] = useState(bill);
    const [isUploading, setIsUploading] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [copied, setCopied] = useState(false);
    const [previewDoc, setPreviewDoc] = useState<{ url: string, name: string } | null>(null);

    // Notes State
    const [noteText, setNoteText] = useState(bill.notes || '');
    const [isSavingNotes, setIsSavingNotes] = useState(false);

    const handleSaveNotes = async () => {
        if (noteText === localBill.notes) return;
        setIsSavingNotes(true);
        try {
            const updated = await updatePurchaseBillNotes(localBill.id, noteText);
            setLocalBill(updated);
        } catch (error) {
            console.error(error);
        } finally {
            setIsSavingNotes(false);
        }
    };

    const handleImagePaste = async (e: React.ClipboardEvent) => {
        const items = e.clipboardData.items;
        if (!items) return;
        
        for (let i = 0; i < items.length; i++) {
            if (items[i].type.indexOf('image') !== -1) {
                e.preventDefault();
                const file = items[i].getAsFile();
                if (!file) continue;
                
                setIsUploading(true);
                try {
                    const uploadData = new FormData();
                    const fileName = `clipboard_${new Date().getTime()}.${file.type.split('/')[1]}`;
                    uploadData.append('file', file, fileName);
                    const res = await fetch('/api/upload', { method: 'POST', body: uploadData });
                    const data = await res.json();
                    if (!res.ok) throw new Error(data.error);

                    const updatedBill = await uploadPurchaseBillDocument(localBill.id, data.url, Object.hasOwn(file, 'name') && file.name !== 'image.png' ? file.name : fileName);
                    setLocalBill(updatedBill);
                } catch (err: any) {
                    alert(err.message || 'Lỗi tải ảnh Clipboard');
                } finally {
                    setIsUploading(false);
                }
            }
        }
    };

    // Pagination hooks
    const itemsPag = usePagination(bill.items || []);
    const allocationsPag = usePagination(bill.allocations || []);

    const handleCancel = async () => {
        if (confirm(`Bạn có chắc chắn muốn HỦY Hóa Đơn ${localBill.code}?\n\nHành động này sẽ:\n- Hủy phiếu Nhập Kho tương ứng\n- Giảm lại công nợ NCC.\n\nLưu ý: Không thể hủy nếu hóa đơn đã có thanh toán.`)) {
            setIsSubmitting(true);
            try {
                const updated = await cancelPurchaseBill(localBill.id);
                setLocalBill(updated);
            } catch (error: any) {
                alert(error.message || "Hủy thất bại. Hóa đơn có thể đã có thanh toán.");
            } finally {
                setIsSubmitting(false);
            }
        }
    };

    const handleCopyPublicLink = () => {
        const publicUrl = `${window.location.origin}/public/purchasing/bills/${bill.id}`;
        navigator.clipboard.writeText(publicUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const documents = React.useMemo(() => {
        if (!localBill.attachment) return [];
        try {
            return JSON.parse(localBill.attachment);
        } catch (e) {
            // Fallback for old single string attachment
            return [{ url: localBill.attachment, name: 'Tài liệu Gốc', uploadedAt: localBill.createdAt }];
        }
    }, [localBill.attachment]);

    const formatMoney = (amount: number) => {
        return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
    };

    const remainingAmount = localBill.totalAmount - (localBill.paidAmount || 0);
    const isOverdue = localBill.dueDate && new Date(localBill.dueDate).getTime() < new Date().getTime() && localBill.status !== 'PAID' && localBill.status !== 'CANCELLED' && remainingAmount > 0;


    const getStatusBadge = (status: string) => {
        switch (status) {
            case 'DRAFT': return <span className="px-2 py-1 rounded-full bg-gray-100 text-gray-700 text-xs font-semibold">Lưu Nháp</span>;
            case 'APPROVED': return <span className="px-2 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold">Đã Duyệt (Nợ)</span>;
            case 'PARTIAL_PAID': return <span className="px-2 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-semibold">Thanh toán 1 phần</span>;
            case 'PAID': return <span className="px-2 py-1 rounded-full bg-green-100 text-green-700 text-xs font-semibold">Đã Thanh Toán Tối Đa</span>;
            default: return <span className="px-2 py-1 rounded-full bg-gray-100 text-gray-700 text-xs font-semibold">{status}</span>;
        }
    };

    const tabs = [
        { id: 'items', label: 'Sản phẩm Nhập', icon: <ShoppingCart size={18} />, count: localBill.items?.length || 0 },
        { id: 'payments', label: 'Thanh Toán (Chi)', icon: <CreditCard size={18} />, count: localBill.allocations?.length || 0 },
        { id: 'tasks', label: 'Công việc', icon: <CheckSquare size={18} />, count: tasks.length },
    ] as const;

    return (
        <div className="p-4 md:p-8 max-w-full mx-auto font-sans bg-slate-50 min-h-screen">
            <div className="flex flex-col lg:flex-row lg:justify-between lg:items-start gap-4 mb-8">
                <div className="flex items-start sm:items-center gap-4">
                    <button
                        onClick={() => router.back()}
                        className="flex items-center justify-center w-10 h-10 rounded-full border border-gray-200 bg-white text-gray-500 cursor-pointer transition-all hover:bg-gray-100 hover:text-gray-900 shrink-0"
                    >
                        <ArrowLeft size={20} />
                    </button>
                    <div>
                        <div className="flex flex-wrap items-center gap-3 mb-1">
                            <h1 className="text-xl md:text-2xl font-bold text-gray-900 m-0 tracking-tight">
                                Hóa Đơn {bill.code}
                            </h1>
                            {getStatusBadge(bill.status)}
                        </div>
                        <p className="text-gray-500 m-0 text-sm">Quản lý chi tiết hóa đơn, xác nhận tiền chi trả cho nhà cung cấp.</p>
                    </div>
                </div>

                <div className="flex flex-wrap gap-3 w-full lg:w-auto">
                    <button
                        onClick={handleCopyPublicLink}
                        className="btn btn-secondary flex-1 sm:flex-none justify-center"
                        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.625rem 1rem', borderRadius: '0.5rem', fontSize: '0.875rem', fontWeight: 500, backgroundColor: 'white', color: '#475569', border: '1px solid #cbd5e1', cursor: 'pointer', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)' }}
                    >
                        <Copy size={16} /> {copied ? 'Đã sao chép' : 'Copy Link Gửi KH'}
                    </button>
                    <Link
                        href={`/public/purchasing/bills/${bill.id}`}
                        target="_blank"
                        className="btn btn-secondary flex-1 sm:flex-none justify-center"
                        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.625rem 1rem', borderRadius: '0.5rem', fontSize: '0.875rem', fontWeight: 500, backgroundColor: '#f1f5f9', color: '#3b82f6', border: '1px solid #bfdbfe', cursor: 'pointer', textDecoration: 'none', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)' }}
                    >
                        <ExternalLink size={16} /> Xem Bản In
                    </Link>
                    {localBill.status === 'APPROVED' && (
                        <button
                            onClick={handleCancel}
                            disabled={isSubmitting}
                            className="btn btn-secondary w-full sm:w-auto justify-center"
                            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.625rem 1rem', borderRadius: '0.5rem', fontSize: '0.875rem', fontWeight: 500, backgroundColor: 'white', color: '#ea580c', border: '1px solid #fdba74', cursor: isSubmitting ? 'not-allowed' : 'pointer', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)' }}
                        >
                            <XCircle size={16} /> {isSubmitting ? 'Đang xử lý...' : 'Hủy Hóa Đơn'}
                        </button>
                    )}
                    {bill.totalAmount > bill.paidAmount && (
                        <Link
                            href={`/purchasing/payments?supplierId=${bill.supplierId}`}
                            className="btn btn-primary w-full sm:w-auto justify-center"
                            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.625rem 1.25rem', borderRadius: '0.5rem', fontSize: '0.875rem', fontWeight: 500, backgroundColor: '#10b981', color: 'white', border: 'none', cursor: 'pointer', textDecoration: 'none', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)' }}
                        >
                            <CreditCard size={18} /> Tạo lệnh Chi tiền
                        </Link>
                    )}
                </div>
            </div>

            {isOverdue && (
                <div className="animate-overdue-bg" style={{ border: '1px solid #fde047', borderRadius: 'var(--radius, 1rem)', padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1.25rem', color: '#854d0e', marginBottom: '2rem', backgroundColor: '#fefce8' }}>
                    <AlertTriangle size={32} className="text-yellow-500" />
                    <div>
                        <h3 style={{ margin: 0, fontSize: '1.15rem', fontWeight: 700 }}>HÓA ĐƠN MUA HÀNG ĐÃ ĐẾN HẠN THANH TOÁN</h3>
                        <p style={{ margin: 0, fontSize: '0.95rem', fontWeight: 500, marginTop: '0.25rem' }}>Hóa đơn này đã đến hạn thanh toán cho Nhà Cung Cấp ({formatDate(localBill.dueDate)}). Vui lòng ưu tiên tạo Lệnh Chi để quyết toán công nợ.</p>
                    </div>
                </div>
            )}

            <div className="flex flex-col xl:flex-row gap-8 w-full items-start">
                {/* Left Column: Details & Tabs */}
                <div className="flex flex-col gap-8 flex-1 min-w-0 w-full">

                    {/* Summary Card */}
                    <div className="bg-white rounded-2xl p-4 md:p-6 border border-gray-200 shadow-sm">
                        <h2 className="text-lg font-semibold text-slate-800 mb-5 flex items-center gap-2">
                            <FileText size={20} className="text-indigo-500" /> Thông tin chung
                        </h2>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                            <div className="sm:col-span-2">
                                <p className="text-xs uppercase font-semibold text-slate-400 mb-1">Nhà Cung Cấp</p>
                                <div className="flex items-center gap-2 overflow-hidden">
                                    <Building size={16} className="text-slate-500 shrink-0" />
                                    <Link href={`/suppliers/${bill.supplierId}`} className="font-semibold text-indigo-600 no-underline hover:underline text-base truncate">
                                        {bill.supplier?.name}
                                    </Link>
                                </div>
                            </div>
                            <div>
                                <p className="text-xs uppercase font-semibold text-slate-400 mb-1">Tham Chiếu Đơn Hàng</p>
                                {bill.order ? (
                                    <Link href={`/purchasing/orders/${bill.order.id}`} className="font-semibold text-indigo-600 no-underline hover:underline text-base">
                                        {bill.order.code}
                                    </Link>
                                ) : <span className="text-slate-400 text-base">-- Không có --</span>}
                            </div>
                            <div>
                                <p className="text-xs uppercase font-semibold text-slate-400 mb-1">Ngày Hóa Đơn</p>
                                <div className="flex items-center gap-2 text-slate-700 font-medium text-base">
                                    <Calendar size={16} className="text-slate-500" />
                                    {formatDate(bill.date)}
                                </div>
                            </div>
                            <div className="sm:col-span-2 lg:col-span-4 mt-2">
                                <p className="text-xs uppercase font-semibold text-slate-400 mb-3">Tình Trạng Kế Toán</p>
                                <div className="flex flex-wrap items-center gap-x-6 gap-y-4">
                                    <div>
                                        <p className="m-0 font-bold text-slate-800 text-lg">{formatMoney(bill.totalAmount)}</p>
                                        <p className="m-0 text-xs text-slate-500">Cần thanh toán</p>
                                    </div>
                                    <div className="text-slate-200 hidden sm:block">|</div>
                                    <div>
                                        <p className="m-0 font-bold text-emerald-500 text-lg">{formatMoney(bill.paidAmount)}</p>
                                        <p className="m-0 text-xs text-slate-500">Đã chi (Đã thanh toán)</p>
                                    </div>
                                    <div className="text-slate-200 hidden sm:block">|</div>
                                    <div>
                                        <p className="m-0 font-bold text-red-500 text-lg">{formatMoney(bill.totalAmount - bill.paidAmount)}</p>
                                        <p className="m-0 text-xs text-slate-500">Dư nợ</p>
                                    </div>
                                </div>
                            </div>

                            {localBill.notes && (
                                <div style={{ gridColumn: '1 / -1' }}>
                                    <p style={{ fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: 600, color: '#94a3b8', marginBottom: '0.25rem' }}>Ghi Chú</p>
                                    <p style={{ margin: 0, color: '#475569', fontSize: '0.875rem', backgroundColor: '#f8fafc', padding: '0.75rem', borderRadius: '0.5rem', border: '1px solid #e2e8f0', whiteSpace: 'pre-wrap' }}>{localBill.notes}</p>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Tabs area */}
                    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm w-full overflow-hidden">
                        <div className="flex border-b border-gray-200 overflow-x-auto hide-scrollbar px-2">
                            {tabs.map((tab) => {
                                const isActive = activeTab === tab.id;
                                return (
                                    <button
                                        key={tab.id}
                                        onClick={() => setActiveTab(tab.id as any)}
                                        className={`flex items-center justify-center gap-2 px-6 py-4 border-none bg-transparent cursor-pointer text-sm whitespace-nowrap transition-all relative
                                            ${isActive ? 'font-semibold text-indigo-600 border-b-2 border-indigo-600' : 'font-medium text-slate-500 border-b-2 border-transparent hover:text-slate-700'}`}
                                    >
                                        {tab.icon} {tab.label}
                                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold
                                            ${isActive ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-slate-500'}`}>
                                            {tab.count}
                                        </span>
                                    </button>
                                );
                            })}
                        </div>

                        <div style={{ padding: '1.5rem' }}>
                            {activeTab === 'items' && (
                                <div style={{ overflowX: 'auto' }}>
                                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
                                        <thead>
                                            <tr style={{ backgroundColor: '#f8fafc', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>
                                                <th style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Sản Phẩm</th>
                                                <th style={{ padding: '0.75rem 1rem', fontWeight: 600, textAlign: 'center' }}>Số Lượng</th>
                                                <th style={{ padding: '0.75rem 1rem', fontWeight: 600, textAlign: 'right' }}>Đơn Giá</th>
                                                <th style={{ padding: '0.75rem 1rem', fontWeight: 600, textAlign: 'center' }}>Thuế (%)</th>
                                                <th style={{ padding: '0.75rem 1rem', fontWeight: 600, textAlign: 'right' }}>Thành Tiền</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {itemsPag.paginatedItems.length === 0 ? (
                                                <tr><td colSpan={5} style={{ textAlign: 'center', padding: '2rem', color: '#94a3b8' }}>Chưa có sản phẩm nào được nhập kho.</td></tr>
                                            ) : (
                                                itemsPag.paginatedItems.map((item: any) => (
                                                    <tr key={item.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                                                        <td style={{ padding: '1rem', fontWeight: 500, color: '#1e293b' }}>
                                                            {item.product?.name || item.productName || 'Sản phẩm không xác định'}
                                                            {item.product?.sku && <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>SKU: {item.product.sku}</div>}
                                                        </td>
                                                        <td style={{ padding: '1rem', textAlign: 'center', color: '#475569' }}>{item.quantity} {item.product?.unit || ''}</td>
                                                        <td style={{ padding: '1rem', textAlign: 'right', color: '#475569' }}>{formatMoney(item.unitPrice)}</td>
                                                        <td style={{ padding: '1rem', textAlign: 'center', color: '#475569' }}>{item.taxRate || 0}%</td>
                                                        <td style={{ padding: '1rem', textAlign: 'right', fontWeight: 600, color: '#0f172a' }}>{formatMoney(item.totalPrice)}</td>
                                                    </tr>
                                                ))
                                            )}
                                            {bill.items?.length > 0 && (
                                                <>
                                                    <tr style={{ backgroundColor: '#f8fafc' }}>
                                                        <td colSpan={4} style={{ padding: '1rem', textAlign: 'right', color: '#64748b' }}>Tổng tiền trước thuế:</td>
                                                        <td style={{ padding: '1rem', textAlign: 'right', fontWeight: 500, color: '#1e293b' }}>{formatMoney(bill.subTotal || 0)}</td>
                                                    </tr>
                                                    <tr style={{ backgroundColor: '#f8fafc' }}>
                                                        <td colSpan={4} style={{ padding: '1rem', textAlign: 'right', color: '#64748b' }}>Tổng tiền thuế:</td>
                                                        <td style={{ padding: '1rem', textAlign: 'right', fontWeight: 500, color: '#1e293b' }}>{formatMoney(bill.taxAmount || 0)}</td>
                                                    </tr>
                                                    <tr style={{ backgroundColor: '#f8fafc', borderTop: '1px solid #e2e8f0' }}>
                                                        <td colSpan={4} style={{ padding: '1rem', textAlign: 'right', fontWeight: 600, color: '#0f172a' }}>Tổng Cộng:</td>
                                                        <td style={{ padding: '1rem', textAlign: 'right', fontWeight: 700, color: '#10b981', fontSize: '1.1rem' }}>{formatMoney(bill.totalAmount)}</td>
                                                    </tr>
                                                </>
                                            )}
                                        </tbody>
                                    </table>
                                    <Pagination {...itemsPag.paginationProps} />
                                </div>
                            )}

                            {activeTab === 'payments' && (
                                <div>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                                        <p style={{ color: '#64748b', fontSize: '0.875rem', margin: 0 }}>Lịch sử các lần chi trả cho Hóa đơn / Lô hàng này.</p>
                                    </div>
                                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
                                        <thead>
                                            <tr style={{ backgroundColor: '#f8fafc', color: '#64748b', borderBottom: '1px solid #e2e8f0' }}>
                                                <th style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Mã Lệnh Chi</th>
                                                <th style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Ngày Phân Bổ</th>
                                                <th style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Hình Thức</th>
                                                <th style={{ padding: '0.75rem 1rem', fontWeight: 600, textAlign: 'right' }}>Số Tiền Đã Cấn Trừ</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {allocationsPag.paginatedItems.length === 0 ? (
                                                <tr><td colSpan={4} style={{ textAlign: 'center', padding: '2rem', color: '#94a3b8' }}>Chưa có thanh toán nào được thực hiện cho hóa đơn này.</td></tr>
                                            ) : (
                                                allocationsPag.paginatedItems.map((allocation: any) => (
                                                    <tr key={allocation.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                                                        <td style={{ padding: '1rem' }}>
                                                            <Link href={`/purchasing/payments/${allocation.payment?.id}`} style={{ fontWeight: 600, color: '#4f46e5', textDecoration: 'none' }} className="hover:underline">
                                                                {allocation.payment?.code}
                                                            </Link>
                                                        </td>
                                                        <td style={{ padding: '1rem', color: '#475569' }}>{formatDate(allocation.createdAt)}</td>
                                                        <td style={{ padding: '1rem' }}>
                                                            {allocation.payment?.paymentMethod === 'BANK_TRANSFER' ? (
                                                                <span className="px-2 py-1 rounded bg-blue-50 text-blue-600 text-xs font-medium">Chuyển Khoản</span>
                                                            ) : (
                                                                <span className="px-2 py-1 rounded bg-amber-50 text-amber-600 text-xs font-medium">Tiền Mặt</span>
                                                            )}
                                                        </td>
                                                        <td style={{ padding: '1rem', textAlign: 'right', fontWeight: 600, color: '#10b981' }}>{formatMoney(allocation.amount)}</td>
                                                    </tr>
                                                ))
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            )}

                            {activeTab === 'tasks' && (
                                <div style={{ border: '1px dashed #cbd5e1', borderRadius: '0.5rem', padding: '1.5rem', textAlign: 'center', color: '#64748b', backgroundColor: '#f8fafc' }}>
                                    Xin vui lòng xem cột Công việc bên phải.
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Right Column: Tasks Panel and Documents */}
                <div className="w-full xl:w-[400px] shrink-0 xl:sticky xl:top-4 flex flex-col gap-6">
                        <div style={{ backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)' }}>
                            <TaskPanel
                                initialTasks={tasks}
                                users={users}
                                entityType="PURCHASE_BILL"
                                entityId={bill.id}
                            />
                        </div>

                        <div style={{ backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)', overflow: 'hidden' }}>
                            <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <h2 style={{ fontSize: '1.125rem', fontWeight: 600, color: '#1e293b', margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                    <FileDown size={20} color="#6366f1" /> Tài liệu đính kèm
                                </h2>
                                <div style={{ position: 'relative' }}>
                                    <input
                                        type="file"
                                        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }}
                                        disabled={isUploading}
                                        onChange={async (e) => {
                                            const file = e.target.files?.[0];
                                            if (!file) return;
                                            setIsUploading(true);
                                            try {
                                                const uploadData = new FormData();
                                                uploadData.append('file', file);
                                                const res = await fetch('/api/upload', { method: 'POST', body: uploadData });
                                                const data = await res.json();
                                                if (!res.ok) throw new Error(data.error);

                                                const updatedBill = await uploadPurchaseBillDocument(localBill.id, data.url, file.name);
                                                setLocalBill(updatedBill);

                                            } catch (err: any) {
                                                alert(err.message || 'Lỗi tải tệp tin');
                                            } finally {
                                                setIsUploading(false);
                                                e.target.value = '';
                                            }
                                        }}
                                    />
                                    <button
                                        disabled={isUploading}
                                        style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.4rem 0.75rem', borderRadius: '0.5rem', backgroundColor: '#e0e7ff', color: '#4f46e5', border: 'none', fontSize: '0.875rem', fontWeight: 600, cursor: isUploading ? 'not-allowed' : 'pointer' }}
                                    >
                                        {isUploading ? 'Đang tải...' : <><Plus size={16} /> Thêm</>}
                                    </button>
                                </div>
                            </div>

                            <div style={{ padding: '1.5rem' }}>
                                {documents.length === 0 ? (
                                    <div style={{ textAlign: 'center', padding: '2rem 1rem', backgroundColor: '#f8fafc', borderRadius: '0.5rem', border: '1px dashed #cbd5e1' }}>
                                        <FileText size={32} color="#cbd5e1" style={{ margin: '0 auto 0.5rem' }} />
                                        <p style={{ color: '#64748b', margin: 0, fontSize: '0.875rem' }}>Chưa có tài liệu đính kèm.</p>
                                    </div>
                                ) : (
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                                        {documents.map((doc: any, idx: number) => (
                                            <div key={idx} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem', backgroundColor: '#f8fafc', borderRadius: '0.5rem', border: '1px solid #e2e8f0' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', overflow: 'hidden' }}>
                                                    <div style={{ width: '36px', height: '36px', flexShrink: 0, borderRadius: '0.5rem', backgroundColor: '#e0e7ff', color: '#4f46e5', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                                        <FileText size={18} />
                                                    </div>
                                                    <div style={{ overflow: 'hidden' }}>
                                                        <button onClick={() => setPreviewDoc({ url: doc.url, name: doc.name || 'Tài liệu đính kèm' })} style={{ fontWeight: 600, color: '#0f172a', border: 'none', background: 'transparent', textAlign: 'left', cursor: 'pointer', padding: 0, display: 'block', marginBottom: '0.1rem', fontSize: '0.875rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} className="hover:text-blue-600" title={doc.name}>
                                                            {doc.name}
                                                        </button>
                                                        <span style={{ fontSize: '0.75rem', color: '#64748b' }}>
                                                            {formatDate(new Date(doc.uploadedAt))}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* GHI CHÚ PANEL */}
                        <div style={{ backgroundColor: 'white', borderRadius: '1rem', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)', overflow: 'hidden' }}>
                            <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid #e2e8f0' }}>
                                <h2 style={{ fontSize: '1.125rem', fontWeight: 600, color: '#1e293b', margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                    <FileText size={20} className="text-emerald-500" /> Ghi chú Hóa Đơn
                                </h2>
                            </div>
                            <div style={{ padding: '1.5rem' }}>
                                <textarea
                                    className="w-full text-sm p-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 min-h-[120px] resize-y"
                                    placeholder="Nhập ghi chú... (Hỗ trợ dán ảnh trực tiếp Ctrl+V)"
                                    value={noteText}
                                    onChange={(e) => setNoteText(e.target.value)}
                                    onBlur={handleSaveNotes}
                                    onPaste={handleImagePaste}
                                />
                                {isSavingNotes && <p className="text-xs text-slate-400 mt-2">Đang lưu ghi chú...</p>}
                            </div>
                        </div>
                    </div>
                </div>

            {previewDoc && (
                <DocumentPreviewModal
                    isOpen={!!previewDoc}
                    onClose={() => setPreviewDoc(null)}
                    fileUrl={previewDoc.url}
                    fileName={previewDoc.name}
                />
            )}
        </div>
    );
}
